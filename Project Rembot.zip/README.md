# HentaiBotJS
UltimateHentaiBot rewritten in JS

Command | Description | Usage
----------------|-------------|--------
`<help` | Get commands of bot | `<help`
`<neko` | Get picture from nekos.life | `<neko [tag]`
`<add` | Add channel to update list | `<add [subreddit]`

## Requirements:
- Discord JS
- Request
